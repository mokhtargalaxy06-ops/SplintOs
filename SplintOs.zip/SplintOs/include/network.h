#ifndef SPLINTOS_NETWORK_H
#define SPLINTOS_NETWORK_H

#include <stdbool.h>

bool network_init(void);
void network_poll(void);

#endif
