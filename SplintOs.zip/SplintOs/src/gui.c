#include "gui.h"
#include "devices.h"

#include <stddef.h>
#include <stdint.h>

#define PACKED __attribute__((packed))

struct PACKED multiboot_info {
    uint32_t flags;
    uint32_t mem_lower, mem_upper, boot_device, cmdline;
    uint32_t mods_count, mods_addr;
    uint8_t syms[16];
    uint32_t mmap_length, mmap_addr;
    uint32_t drives_length, drives_addr, config_table, boot_loader_name, apm_table;
    uint32_t vbe_control_info, vbe_mode_info;
    uint16_t vbe_mode, vbe_interface_seg, vbe_interface_off, vbe_interface_len;
    uint64_t framebuffer_addr;
    uint32_t framebuffer_pitch, framebuffer_width, framebuffer_height;
    uint8_t framebuffer_bpp, framebuffer_type;
    uint8_t color_info[6];
};

static uint32_t *pixels;
static uint32_t width, height, pitch;
static bool network_connected;
static uint8_t selected;
static int cursor_x = 400, cursor_y = 300;

static const uint8_t font[][7] = {
    [' ' - 32]={0,0,0,0,0,0,0}, ['!' - 32]={4,4,4,4,4,0,4},
    ['.' - 32]={0,0,0,0,0,6,6}, [':' - 32]={0,6,6,0,6,6,0},
    ['/' - 32]={1,1,2,4,8,16,16}, ['0' - 32]={14,17,19,21,25,17,14},
    ['1' - 32]={4,12,4,4,4,4,14}, ['2' - 32]={14,17,1,2,4,8,31},
    ['3' - 32]={30,1,1,14,1,1,30}, ['4' - 32]={2,6,10,18,31,2,2},
    ['5' - 32]={31,16,16,30,1,1,30}, ['6' - 32]={14,16,16,30,17,17,14},
    ['7' - 32]={31,1,2,4,8,8,8}, ['8' - 32]={14,17,17,14,17,17,14},
    ['9' - 32]={14,17,17,15,1,1,14}, ['A' - 32]={14,17,17,31,17,17,17},
    ['B' - 32]={30,17,17,30,17,17,30}, ['C' - 32]={14,17,16,16,16,17,14},
    ['D' - 32]={30,17,17,17,17,17,30}, ['E' - 32]={31,16,16,30,16,16,31},
    ['F' - 32]={31,16,16,30,16,16,16}, ['G' - 32]={14,17,16,23,17,17,15},
    ['H' - 32]={17,17,17,31,17,17,17}, ['I' - 32]={14,4,4,4,4,4,14},
    ['J' - 32]={7,2,2,2,2,18,12}, ['K' - 32]={17,18,20,24,20,18,17},
    ['L' - 32]={16,16,16,16,16,16,31}, ['M' - 32]={17,27,21,21,17,17,17},
    ['N' - 32]={17,25,21,19,17,17,17}, ['O' - 32]={14,17,17,17,17,17,14},
    ['P' - 32]={30,17,17,30,16,16,16}, ['Q' - 32]={14,17,17,17,21,18,13},
    ['R' - 32]={30,17,17,30,20,18,17}, ['S' - 32]={15,16,16,14,1,1,30},
    ['T' - 32]={31,4,4,4,4,4,4}, ['U' - 32]={17,17,17,17,17,17,14},
    ['V' - 32]={17,17,17,17,17,10,4}, ['W' - 32]={17,17,17,21,21,21,10},
    ['X' - 32]={17,17,10,4,10,17,17}, ['Y' - 32]={17,17,10,4,4,4,4},
    ['Z' - 32]={31,1,2,4,8,16,31},
};

static void rectangle(int x, int y, int w, int h, uint32_t color)
{
    if (x < 0 || y < 0 || x + w > (int)width || y + h > (int)height) return;
    for (int py = y; py < y + h; ++py) {
        uint32_t *line = (uint32_t *)((uint8_t *)pixels + py * pitch);
        for (int px = x; px < x + w; ++px) line[px] = color;
    }
}

static void character(int x, int y, char c, uint32_t color, int scale)
{
    if (c >= 'a' && c <= 'z') c -= 32;
    if (c < 32 || c > 'Z') c = ' ';
    for (int row = 0; row < 7; ++row)
        for (int col = 0; col < 5; ++col)
            if (font[(unsigned)c - 32][row] & (1U << (4 - col)))
                rectangle(x + col * scale, y + row * scale, scale, scale, color);
}

static void text(int x, int y, const char *value, uint32_t color, int scale)
{
    while (*value) {
        character(x, y, *value++, color, scale);
        x += 6 * scale;
    }
}

static void button(int index, int x, const char *label)
{
    uint32_t fill = selected == index ? 0x2563EB : 0x25334A;
    rectangle(x, 490, 170, 52, selected == index ? 0x60A5FA : 0x334155);
    rectangle(x + 2, 492, 166, 48, fill);
    text(x + 20, 507, label, 0xFFFFFF, 2);
}

static void draw(void)
{
    rectangle(0, 0, (int)width, (int)height, 0x081426);
    rectangle(0, 0, (int)width, 58, 0x0F1F36);
    rectangle(24, 14, 30, 30, 0x38BDF8);
    rectangle(31, 21, 16, 16, 0x0F1F36);
    text(68, 17, "SPLINTOS", 0xF8FAFC, 3);
    text((int)width - 184, 22, network_connected ? "ONLINE" : "OFFLINE",
         network_connected ? 0x4ADE80 : 0xF87171, 2);

    text(54, 102, "WELCOME", 0xF8FAFC, 4);
    text(55, 143, "YOUR SMALL GRAPHICAL OPERATING SYSTEM", 0x94A3B8, 2);

    rectangle(54, 195, 692, 226, 0x13233A);
    rectangle(55, 196, 690, 224, 0x101C30);
    text(82, 224, "SYSTEM OVERVIEW", 0x7DD3FC, 2);
    text(82, 272, "KERNEL", 0x94A3B8, 2);
    text(250, 272, "RUNNING", 0x4ADE80, 2);
    text(82, 311, "NETWORK", 0x94A3B8, 2);
    text(250, 311, network_connected ? "10.0.2.15" : "NOT FOUND",
         network_connected ? 0x4ADE80 : 0xF87171, 2);
    text(82, 350, "GRAPHICS", 0x94A3B8, 2);
    text(250, 350, "FRAMEBUFFER", 0xF8FAFC, 2);
    text(82, 389, "CONTROL", 0x94A3B8, 2);
    text(250, 389, "ARROWS AND ENTER", 0xF8FAFC, 2);

    button(0, 54, "NETWORK");
    button(1, 315, "FILES");
    button(2, 576, "ABOUT");
    text(54, 566, "USE LEFT/RIGHT TO SELECT", 0x64748B, 1);

    /* High-contrast software pointer. */
    for (int i = 0; i < 15; ++i) {
        rectangle(cursor_x, cursor_y + i, 2 + i / 2, 1, 0xFFFFFF);
    }
    rectangle(cursor_x + 3, cursor_y + 3, 2, 7, 0x0F172A);
}

bool gui_init(uint32_t address)
{
    const struct multiboot_info *info = (const struct multiboot_info *)(uintptr_t)address;
    if ((info->flags & (1U << 12)) == 0 || info->framebuffer_type != 1 ||
        info->framebuffer_bpp != 32 || info->framebuffer_addr > 0xFFFFFFFFULL ||
        info->framebuffer_width < 800 || info->framebuffer_height < 600) return false;
    pixels = (uint32_t *)(uintptr_t)(uint32_t)info->framebuffer_addr;
    width = info->framebuffer_width;
    height = info->framebuffer_height;
    pitch = info->framebuffer_pitch;
    draw();
    return true;
}

void gui_set_network(bool connected)
{
    network_connected = connected;
    draw();
}

void gui_poll(void)
{
    bool redraw = false;
    enum input_key key = keyboard_take_key();
    if (key == KEY_LEFT) { selected = selected == 0 ? 2 : (uint8_t)(selected - 1); redraw = true; }
    else if (key == KEY_RIGHT || key == KEY_TAB) { selected = (uint8_t)((selected + 1) % 3); redraw = true; }

    struct mouse_state state = mouse_take_state();
    if (state.changed) {
        cursor_x += state.dx;
        cursor_y += state.dy;
        if (cursor_x < 0) cursor_x = 0;
        if (cursor_y < 0) cursor_y = 0;
        if (cursor_x > (int)width - 16) cursor_x = (int)width - 16;
        if (cursor_y > (int)height - 16) cursor_y = (int)height - 16;
        if (state.left && cursor_y >= 490 && cursor_y <= 542) {
            if (cursor_x >= 54 && cursor_x <= 224) selected = 0;
            else if (cursor_x >= 315 && cursor_x <= 485) selected = 1;
            else if (cursor_x >= 576 && cursor_x <= 746) selected = 2;
        }
        redraw = true;
    }
    if (redraw) draw();
}
