#include "network.h"

#include "kernel.h"

#include <stddef.h>
#include <stdint.h>

#define PACKED __attribute__((packed))

enum {
    PCI_CONFIG_ADDRESS = 0xCF8,
    PCI_CONFIG_DATA = 0xCFC,
    RTL_VENDOR = 0x10EC,
    RTL_DEVICE = 0x8139,
    RX_BUFFER_SIZE = 8192 + 16 + 1500,
    ETH_ARP = 0x0806,
    ETH_IPV4 = 0x0800,
};

struct PACKED ethernet_header {
    uint8_t destination[6];
    uint8_t source[6];
    uint16_t type;
};

struct PACKED arp_packet {
    uint16_t hardware_type;
    uint16_t protocol_type;
    uint8_t hardware_size;
    uint8_t protocol_size;
    uint16_t operation;
    uint8_t sender_mac[6];
    uint8_t sender_ip[4];
    uint8_t target_mac[6];
    uint8_t target_ip[4];
};

struct PACKED ipv4_header {
    uint8_t version_ihl;
    uint8_t dscp_ecn;
    uint16_t total_length;
    uint16_t identification;
    uint16_t flags_fragment;
    uint8_t ttl;
    uint8_t protocol;
    uint16_t checksum;
    uint8_t source[4];
    uint8_t destination[4];
};

struct PACKED icmp_header {
    uint8_t type;
    uint8_t code;
    uint16_t checksum;
};

static uint16_t io_base;
static uint16_t rx_offset;
static uint8_t mac[6];
static const uint8_t ip[4] = {10, 0, 2, 15};
static uint8_t rx_buffer[RX_BUFFER_SIZE] __attribute__((aligned(16)));
static uint8_t tx_buffer[4][1536] __attribute__((aligned(16)));
static uint8_t tx_index;

static inline void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline void outw(uint16_t port, uint16_t value)
{
    __asm__ volatile ("outw %0, %1" : : "a"(value), "Nd"(port));
}

static inline void outl(uint16_t port, uint32_t value)
{
    __asm__ volatile ("outl %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline uint16_t inw(uint16_t port)
{
    uint16_t value;
    __asm__ volatile ("inw %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline uint32_t inl(uint16_t port)
{
    uint32_t value;
    __asm__ volatile ("inl %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static void memory_copy(void *destination, const void *source, size_t length)
{
    uint8_t *to = destination;
    const uint8_t *from = source;
    while (length-- != 0) {
        *to++ = *from++;
    }
}

static bool memory_equal(const void *left, const void *right, size_t length)
{
    const uint8_t *a = left;
    const uint8_t *b = right;
    while (length-- != 0) {
        if (*a++ != *b++) {
            return false;
        }
    }
    return true;
}

static uint16_t swap16(uint16_t value)
{
    return (uint16_t)((value << 8) | (value >> 8));
}

static uint16_t checksum(const void *data, size_t length)
{
    const uint8_t *bytes = data;
    uint32_t sum = 0;

    while (length > 1) {
        sum += (uint16_t)((uint16_t)bytes[0] << 8 | bytes[1]);
        bytes += 2;
        length -= 2;
    }
    if (length != 0) {
        sum += (uint16_t)bytes[0] << 8;
    }
    while ((sum >> 16) != 0) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    return swap16((uint16_t)~sum);
}

static uint32_t pci_read(uint8_t bus, uint8_t slot, uint8_t function,
                         uint8_t offset)
{
    uint32_t address = 0x80000000U | (uint32_t)bus << 16 |
                       (uint32_t)slot << 11 | (uint32_t)function << 8 |
                       (offset & 0xFC);
    outl(PCI_CONFIG_ADDRESS, address);
    return inl(PCI_CONFIG_DATA);
}

static void pci_write(uint8_t bus, uint8_t slot, uint8_t function,
                      uint8_t offset, uint32_t value)
{
    uint32_t address = 0x80000000U | (uint32_t)bus << 16 |
                       (uint32_t)slot << 11 | (uint32_t)function << 8 |
                       (offset & 0xFC);
    outl(PCI_CONFIG_ADDRESS, address);
    outl(PCI_CONFIG_DATA, value);
}

static bool find_rtl8139(uint8_t *found_bus, uint8_t *found_slot)
{
    for (uint16_t bus = 0; bus < 256; ++bus) {
        for (uint8_t slot = 0; slot < 32; ++slot) {
            uint32_t id = pci_read((uint8_t)bus, slot, 0, 0);
            if ((uint16_t)id == RTL_VENDOR && (uint16_t)(id >> 16) == RTL_DEVICE) {
                *found_bus = (uint8_t)bus;
                *found_slot = slot;
                return true;
            }
        }
    }
    return false;
}

static void transmit(const void *frame, uint16_t length)
{
    uint16_t wire_length = length < 60 ? 60 : length;
    uint8_t *buffer = tx_buffer[tx_index];
    memory_copy(buffer, frame, length);
    for (uint16_t i = length; i < wire_length; ++i) {
        buffer[i] = 0;
    }

    outl((uint16_t)(io_base + 0x20 + tx_index * 4), (uint32_t)(uintptr_t)buffer);
    outl((uint16_t)(io_base + 0x10 + tx_index * 4), wire_length);
    tx_index = (uint8_t)((tx_index + 1) & 3);
}

static void handle_arp(uint8_t *frame, uint16_t length)
{
    if (length < sizeof(struct ethernet_header) + sizeof(struct arp_packet)) {
        return;
    }
    struct ethernet_header *ethernet = (struct ethernet_header *)frame;
    struct arp_packet *arp = (struct arp_packet *)(ethernet + 1);
    if (swap16(arp->operation) != 1 || !memory_equal(arp->target_ip, ip, 4)) {
        return;
    }

    uint8_t requester_mac[6];
    uint8_t requester_ip[4];
    memory_copy(requester_mac, arp->sender_mac, 6);
    memory_copy(requester_ip, arp->sender_ip, 4);
    memory_copy(ethernet->destination, requester_mac, 6);
    memory_copy(ethernet->source, mac, 6);
    arp->operation = swap16(2);
    memory_copy(arp->target_mac, requester_mac, 6);
    memory_copy(arp->target_ip, requester_ip, 4);
    memory_copy(arp->sender_mac, mac, 6);
    memory_copy(arp->sender_ip, ip, 4);
    transmit(frame, sizeof(*ethernet) + sizeof(*arp));
}

static void handle_ipv4(uint8_t *frame, uint16_t length)
{
    if (length < sizeof(struct ethernet_header) + sizeof(struct ipv4_header)) {
        return;
    }
    struct ethernet_header *ethernet = (struct ethernet_header *)frame;
    struct ipv4_header *ipv4 = (struct ipv4_header *)(ethernet + 1);
    uint8_t header_length = (uint8_t)((ipv4->version_ihl & 0x0F) * 4);
    uint16_t total_length = swap16(ipv4->total_length);
    if ((ipv4->version_ihl >> 4) != 4 || header_length < 20 ||
        total_length < header_length + sizeof(struct icmp_header) ||
        sizeof(*ethernet) + total_length > length || ipv4->protocol != 1 ||
        !memory_equal(ipv4->destination, ip, 4)) {
        return;
    }
    struct icmp_header *icmp = (struct icmp_header *)((uint8_t *)ipv4 + header_length);
    if (icmp->type != 8 || icmp->code != 0) {
        return;
    }

    uint8_t old_mac[6];
    uint8_t old_ip[4];
    memory_copy(old_mac, ethernet->source, 6);
    memory_copy(old_ip, ipv4->source, 4);
    memory_copy(ethernet->destination, old_mac, 6);
    memory_copy(ethernet->source, mac, 6);
    memory_copy(ipv4->destination, old_ip, 4);
    memory_copy(ipv4->source, ip, 4);
    ipv4->ttl = 64;
    ipv4->checksum = 0;
    ipv4->checksum = checksum(ipv4, header_length);
    icmp->type = 0;
    icmp->checksum = 0;
    icmp->checksum = checksum(icmp, total_length - header_length);
    transmit(frame, (uint16_t)(sizeof(*ethernet) + total_length));
}

static void handle_frame(uint8_t *frame, uint16_t length)
{
    if (length < sizeof(struct ethernet_header)) {
        return;
    }
    struct ethernet_header *ethernet = (struct ethernet_header *)frame;
    uint16_t type = swap16(ethernet->type);
    if (type == ETH_ARP) {
        handle_arp(frame, length);
    } else if (type == ETH_IPV4) {
        handle_ipv4(frame, length);
    }
}

bool network_init(void)
{
    uint8_t bus;
    uint8_t slot;
    if (!find_rtl8139(&bus, &slot)) {
        return false;
    }

    uint32_t bar0 = pci_read(bus, slot, 0, 0x10);
    if ((bar0 & 1U) == 0) {
        terminal_write("RTL8139 memory BAR is not supported.\n");
        return false;
    }
    io_base = (uint16_t)(bar0 & ~3U);

    uint32_t command = pci_read(bus, slot, 0, 0x04);
    pci_write(bus, slot, 0, 0x04, command | 0x0005U);
    outb((uint16_t)(io_base + 0x52), 0);
    outb((uint16_t)(io_base + 0x37), 0x10);
    while ((inb((uint16_t)(io_base + 0x37)) & 0x10) != 0) {
    }

    for (uint8_t i = 0; i < 6; ++i) {
        mac[i] = inb((uint16_t)(io_base + i));
    }
    outl((uint16_t)(io_base + 0x30), (uint32_t)(uintptr_t)rx_buffer);
    outw((uint16_t)(io_base + 0x3C), 0);
    outl((uint16_t)(io_base + 0x44), 0x0000E70A);
    outb((uint16_t)(io_base + 0x37), 0x0C);
    return true;
}

void network_poll(void)
{
    while ((inb((uint16_t)(io_base + 0x37)) & 1U) == 0) {
        uint8_t *packet = rx_buffer + rx_offset;
        uint16_t status = *(volatile uint16_t *)packet;
        uint16_t length = *(volatile uint16_t *)(packet + 2);
        if ((status & 1U) == 0 || length < 4 || length > 1536) {
            outb((uint16_t)(io_base + 0x37), 0x04);
            rx_offset = 0;
            outl((uint16_t)(io_base + 0x30), (uint32_t)(uintptr_t)rx_buffer);
            return;
        }

        handle_frame(packet + 4, (uint16_t)(length - 4));
        rx_offset = (uint16_t)((rx_offset + length + 4 + 3) & ~3U);
        rx_offset %= 8192;
        outw((uint16_t)(io_base + 0x38), (uint16_t)(rx_offset - 16));
    }
}
